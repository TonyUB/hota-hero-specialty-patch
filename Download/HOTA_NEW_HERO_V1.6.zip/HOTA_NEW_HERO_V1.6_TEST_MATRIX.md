# V1.6 验证范围 / Verification Scope

| 项目 | 本轮结果 |
| --- | --- |
| 双 EXE、HotA.dll、专属模块校验和 | 通过 |
| 九头迁移代码与原验收代码指令语义、回退目标 | 通过 |
| 历史战争机器、寻宝、龙族等冻结层 | 对照 V1.53 通过 |
| 两份 215 帧图集及全部非目标帧 | 通过 |
| 头像、动画、音效、中文资源隔离 | 通过 |
| Standard / HD 实际主菜单 | 两者通过 |
| HD 瓦伦头像、当前与下一级说明 | 通过 |
| HD 连续升级首领、射手、斥候 | 通过；金币 920→900→870→850，基础兵 42→41→40→39 |
| Standard 塔博克实际新局 | 通过；0/4/1/1、两项技能、无书、1 九头、头像及说明 |
| 全部战斗动画与反击、攻城、联机、全部旧英雄 | 本轮未逐项重测；沿用此前验收及冻结边界 |

Standard and HD both reached the main menu. This integration rechecked the
Valen upgrade UI in HD and Tabok's new-game profile in Standard. Prior accepted
battle evidence is inherited; it is not represented as a new complete regression.
